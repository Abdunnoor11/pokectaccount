from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Debtor)
admin.site.register(Account)
admin.site.register(Lender)
admin.site.register(Invest)
admin.site.register(Landowner)
admin.site.register(Land)
admin.site.register(Advance)
